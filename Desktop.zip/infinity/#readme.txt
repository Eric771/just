wget https://go.dev/dl/go1.19.4.linux-amd64.tar.gz
rm -rf /usr/local/go && tar -C /usr/local -xzf go1.19.4.linux-amd64.tar.gz
paste this:

export PATH=$PATH:/usr/local/go/bin
type ctrl x + y
nano /etc/profile
source /etc/profile
go env -w GO111MODULE=off
